<?php

$first_number = 26;

$second_number = 21;

if ($first_number > $second_number){

echo "$first_number on suurempi kuin $second_number";

}else{

echo "$second_number on suurempi kuin $first_number";

}

?>