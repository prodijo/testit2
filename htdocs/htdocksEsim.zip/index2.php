<?php
echo "Hello world";	
?>

