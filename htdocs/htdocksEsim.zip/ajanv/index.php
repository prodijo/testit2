<!DOCTYPE html>
<html>
<head>
    <title>Ajanvarausjärjestelmä</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Tervetuloa ajanvaraukseen</h1>
    <nav>
        <a href="varaa.php">Varaa aika</a> |
        <a href="varaukset.php">Katso varaukset</a>
    </nav>
</body>
</html>