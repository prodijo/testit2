﻿<?php include("top.inc"); ?>

<br><img src="images/tekstilogo.gif" width="406" height="62" alt="">
<br><br><br><img src="images/nuija.jpg" width="285" heigth="342" alt="">

<?php include("bottom.inc") ?>