﻿<?php include("top.inc"); ?>
<br><img src="images/tekstilogo.gif" width="406" height="62" alt=""><br><br>
<table border="0" cellpadding="2" cellspacing="0" width="400">
<tr>
	<td height="16" class="orange" valign="middle" align="center">Sanahaku</td>
</tr>
<tr>
	<td height="40" class="gray" align="center"><form method="post" action="hae.php">
		
		 <input type="text" name="hakusanat" size="30" maxlength="255">
		 <input type="submit" value="Suorita haku">
		
		</form>
	</td>
</tr>
</table>		
		
<?php include("bottom.inc"); ?>